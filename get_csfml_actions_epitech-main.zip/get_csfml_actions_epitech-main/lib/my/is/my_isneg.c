/*
** EPITECH PROJECT, 2021
** Task04 - my_isneg.c
** File description:
** abc
*/

#include "../../../include/my_lib.h"

int my_isneg(int n)
{
    if (n > -1) {
        return 0;
    } else {
        return 1;
    }
}

