/*
** EPITECH PROJECT, 2021
** Task0? - my_put_nbr.c
** File description:
** abc
*/

#include "../../../include/my_lib.h"

int my_put_nbr(int nb)
{
    my_putnbr_base(nb, "0123456789");
}

void my_put_ptr(void *ptr)
{
    my_putptr_base(ptr, "0123456789");
}
