/*
** EPITECH PROJECT, 2021
** get_csfml_keys (Workspace)
** File description:
** get.c
*/

#include "../../include/my_key.h"

move_t get_key(move_t move)
{
    sfEvent event;
    return move;
}