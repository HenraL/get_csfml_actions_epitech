/*
** EPITECH PROJECT, 2021
** runner - my_sleep.h
** File description:
** jitter jitter
*/

#ifndef MY_SLEEP_H_
#define MY_SLEEP_H_

void sleep(unsigned int time_in_ms);

#endif