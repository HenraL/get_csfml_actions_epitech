/*
** EPITECH PROJECT, 2021
** runner - my_mouse.h
** File description:
** jitter jitter
*/

#ifndef MY_MOUSE_H_
#define MY_MOUSE_H_

#include <SFML/Window/Event.h>
#include <Event.h>

#endif