/*
** EPITECH PROJECT, 2021
** my_screensaver - help.h
** File description:
** jitter jitter
*/

#ifndef MY_HELP_H_
#define MY_HELP_H_

int help_display(int index);
void help_general_help_calling(void);
void help_general_help_h_options(void);
void help_general_help_example(void);
void help_in_general(int index);
void help_prog_options_calling(void);
void help_prog_options_p_options(void);
void help_prog_options_example(void);
void help_prog_options(int index);
void help_rgba_calling(void);
void help_rgba_c_options(void);
void help_rgba_example(void);
void help_rgba(int index);
void help_speed_calling(void);
void help_speed_s_options(void);
void help_speed_example(void);
void help_speed(int index);

#endif