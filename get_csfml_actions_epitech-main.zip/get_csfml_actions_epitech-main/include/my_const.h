/*
** EPITECH PROJECT, 2021
** runner - my_const.h
** File description:
** jitter jitter
*/

#ifndef MY_CONST_H_
#define MY_CONST_H_

#define Window_Style 0
#define WSNone 0
#define WSTitlebar 1
#define WSResize 2
#define WSClose 4
#define WSDefault 7
#define WSFullscreen 8



#endif