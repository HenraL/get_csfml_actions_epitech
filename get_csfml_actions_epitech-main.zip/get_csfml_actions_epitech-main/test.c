/*
** EPITECH PROJECT, 2021
** get_csfml_keys - test.c
** File description:
**
*/

// #include "include/my_lib.h"

int main(int argc, char **argv)
{
    my_putstr("The files work.");
}
